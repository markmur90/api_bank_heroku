from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import SepaCreditTransferRequest, SepaCreditTransferResponse, SepaCreditTransferDetailsResponse
from .serializers import (
    SepaCreditTransferRequestSerializer,
    SepaCreditTransferResponseSerializer,
    SepaCreditTransferDetailsResponseSerializer,
)

class CreateSepaCreditTransferView(APIView):
    def post(self, request):
        serializer = SepaCreditTransferRequestSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class GetSepaCreditTransferStatusView(APIView):
    def get(self, request, payment_id):
        try:
            transfer = SepaCreditTransferResponse.objects.get(payment_id=payment_id)
            serializer = SepaCreditTransferResponseSerializer(transfer)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except SepaCreditTransferResponse.DoesNotExist:
            return Response({"error": "Sepa Credit Transfer not found"}, status=status.HTTP_404_NOT_FOUND)

class GetSepaCreditTransferDetailsView(APIView):
    def get(self, request, payment_id):
        try:
            details = SepaCreditTransferDetailsResponse.objects.get(payment_id=payment_id)
            serializer = SepaCreditTransferDetailsResponseSerializer(details)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except SepaCreditTransferDetailsResponse.DoesNotExist:
            return Response({"error": "Sepa Credit Transfer details not found"}, status=status.HTTP_404_NOT_FOUND)

class CancelSepaCreditTransferView(APIView):
    def delete(self, request, payment_id):
        try:
            transfer = SepaCreditTransferResponse.objects.get(payment_id=payment_id)
            transfer.delete()
            return Response({"message": "Sepa Credit Transfer cancelled successfully"}, status=status.HTTP_200_OK)
        except SepaCreditTransferResponse.DoesNotExist:
            return Response({"error": "Sepa Credit Transfer not found"}, status=status.HTTP_404_NOT_FOUND)

class RetrySecondFactorView(APIView):
    def patch(self, request, payment_id):
        try:
            transfer = SepaCreditTransferResponse.objects.get(payment_id=payment_id)
            serializer = SepaCreditTransferResponseSerializer(transfer, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except SepaCreditTransferResponse.DoesNotExist:
            return Response({"error": "Sepa Credit Transfer not found"}, status=status.HTTP_404_NOT_FOUND)
