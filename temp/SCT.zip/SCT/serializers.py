from rest_framework import serializers
from rest_framework.fields import DateField
from .models import (
    Address,
    Debtor,
    Creditor,
    DebtorAccount,
    CreditorAccount,
    PaymentIdentification,
    InstructedAmount,
    CreditorAgent,
    SepaCreditTransferRequest,
    SepaCreditTransferResponse,
    SepaCreditTransferDetailsResponse,
)

class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ['country', 'street_and_house_number', 'zip_code_and_city']

class DebtorSerializer(serializers.ModelSerializer):
    debtor_postal_address = AddressSerializer()

    class Meta:
        model = Debtor
        fields = ['debtor_name', 'debtor_postal_address']

class CreditorSerializer(serializers.ModelSerializer):
    creditor_postal_address = AddressSerializer()

    class Meta:
        model = Creditor
        fields = ['creditor_name', 'creditor_postal_address']

class DebtorAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = DebtorAccount
        fields = ['iban', 'currency']

class CreditorAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = CreditorAccount
        fields = ['iban', 'currency']

class PaymentIdentificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentIdentification
        fields = ['end_to_end_id', 'instruction_id']
        read_only_fields = ['end_to_end_id', 'instruction_id']

class InstructedAmountSerializer(serializers.ModelSerializer):
    class Meta:
        model = InstructedAmount
        fields = ['amount', 'currency']

class CreditorAgentSerializer(serializers.ModelSerializer):
    class Meta:
        model = CreditorAgent
        fields = ['financial_institution_id']

class SepaCreditTransferRequestSerializer(serializers.ModelSerializer):
    requested_execution_date = DateField(format='%Y-%m-%d', input_formats=['%Y-%m-%d'])
    debtor = DebtorSerializer()
    debtor_account = DebtorAccountSerializer()
    payment_identification = PaymentIdentificationSerializer()
    instructed_amount = InstructedAmountSerializer()
    creditor_agent = CreditorAgentSerializer()
    creditor = CreditorSerializer()
    creditor_account = CreditorAccountSerializer()

    class Meta:
        model = SepaCreditTransferRequest
        fields = [
            'purpose_code',
            'requested_execution_date',
            'debtor',
            'debtor_account',
            'payment_identification',
            'instructed_amount',
            'creditor_agent',
            'creditor',
            'creditor_account',
            'remittance_information_structured',
            'remittance_information_unstructured',
        ]

class SepaCreditTransferResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = SepaCreditTransferResponse
        fields = ['transaction_status', 'payment_id', 'auth_id']
        read_only_fields = ['payment_id', 'auth_id']

class SepaCreditTransferDetailsResponseSerializer(serializers.ModelSerializer):
    requested_execution_date = DateField(format='%Y-%m-%d', input_formats=['%Y-%m-%d'])
    debtor = DebtorSerializer()
    debtor_account = DebtorAccountSerializer()
    payment_identification = PaymentIdentificationSerializer()
    instructed_amount = InstructedAmountSerializer()
    creditor_agent = CreditorAgentSerializer()
    creditor = CreditorSerializer()
    creditor_account = CreditorAccountSerializer()

    class Meta:
        model = SepaCreditTransferDetailsResponse
        fields = [
            'transaction_status',
            'payment_id',
            'purpose_code',
            'requested_execution_date',
            'debtor',
            'debtor_account',
            'creditor_agent',
            'creditor',
            'creditor_account',
            'payment_identification',
            'instructed_amount',
            'remittance_information_structured',
            'remittance_information_unstructured',
        ]
