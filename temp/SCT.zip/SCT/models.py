from django.db import models
import uuid
import random
import string
from .choices import TRANSACTION_STATUS_CHOICES, ACTION_CHOICES

def generate_identifier():
    return ''.join(random.choices(string.ascii_letters + string.digits + ".-", k=35))

class Address(models.Model):
    country = models.CharField(max_length=2)
    street_and_house_number = models.CharField(max_length=70, null=True, blank=True)
    zip_code_and_city = models.CharField(max_length=70, null=True, blank=True)

class Debtor(models.Model):
    debtor_name = models.CharField(max_length=140)
    debtor_postal_address = models.OneToOneField(Address, on_delete=models.CASCADE, null=True, blank=True)

class Creditor(models.Model):
    creditor_name = models.CharField(max_length=70)
    creditor_postal_address = models.OneToOneField(Address, on_delete=models.CASCADE, null=True, blank=True)

class DebtorAccount(models.Model):
    iban = models.CharField(max_length=34)
    currency = models.CharField(max_length=3)

class CreditorAccount(models.Model):
    iban = models.CharField(max_length=34)
    currency = models.CharField(max_length=3)

class PaymentIdentification(models.Model):
    end_to_end_id = models.CharField(
        max_length=35, 
        null=True, 
        blank=True, 
        default=generate_identifier
    )
    instruction_id = models.CharField(
        max_length=35, 
        null=True, 
        blank=True, 
        default=generate_identifier
    )

class InstructedAmount(models.Model):
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    currency = models.CharField(max_length=3)

class CreditorAgent(models.Model):
    financial_institution_id = models.CharField(max_length=255, null=True, blank=True)

class SepaCreditTransferRequest(models.Model):
    purpose_code = models.CharField(max_length=4, null=True, blank=True)
    requested_execution_date = models.DateField(null=True, blank=True)
    debtor = models.OneToOneField(Debtor, on_delete=models.CASCADE)
    debtor_account = models.OneToOneField(DebtorAccount, on_delete=models.CASCADE)
    payment_identification = models.OneToOneField(PaymentIdentification, on_delete=models.CASCADE, null=True, blank=True)
    instructed_amount = models.OneToOneField(InstructedAmount, on_delete=models.CASCADE)
    creditor_agent = models.OneToOneField(CreditorAgent, on_delete=models.CASCADE)
    creditor = models.OneToOneField(Creditor, on_delete=models.CASCADE)
    creditor_account = models.OneToOneField(CreditorAccount, on_delete=models.CASCADE)
    remittance_information_structured = models.CharField(max_length=140, null=True, blank=True)
    remittance_information_unstructured = models.CharField(max_length=140, null=True, blank=True)

class SepaCreditTransferResponse(models.Model):
    sepa_credit_transfer_request = models.ForeignKey(SepaCreditTransferRequest, on_delete=models.CASCADE, related_name="responses")
    transaction_status = models.CharField(max_length=10, choices=TRANSACTION_STATUS_CHOICES)
    payment_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    auth_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)

class SepaCreditTransferDetailsResponse(models.Model):
    sepa_credit_transfer_request = models.ForeignKey(SepaCreditTransferRequest, on_delete=models.CASCADE, related_name="details_responses")
    transaction_status = models.CharField(max_length=10, choices=TRANSACTION_STATUS_CHOICES)
    payment_id = models.CharField(max_length=255)
    purpose_code = models.CharField(max_length=4, null=True, blank=True)
    requested_execution_date = models.DateField(null=True, blank=True)
    debtor = models.OneToOneField(Debtor, on_delete=models.CASCADE)
    debtor_account = models.OneToOneField(DebtorAccount, on_delete=models.CASCADE)
    creditor_agent = models.OneToOneField(CreditorAgent, on_delete=models.CASCADE)
    creditor = models.OneToOneField(Creditor, on_delete=models.CASCADE)
    creditor_account = models.OneToOneField(CreditorAccount, on_delete=models.CASCADE)
    payment_identification = models.OneToOneField(PaymentIdentification, on_delete=models.CASCADE, null=True, blank=True)
    instructed_amount = models.OneToOneField(InstructedAmount, on_delete=models.CASCADE)
    remittance_information_structured = models.CharField(max_length=140, null=True, blank=True)
    remittance_information_unstructured = models.CharField(max_length=140, null=True, blank=True)

class SepaCreditTransferUpdateScaRequest(models.Model):
    sepa_credit_transfer_request = models.ForeignKey(SepaCreditTransferRequest, on_delete=models.CASCADE, related_name="sca_updates")
    action = models.CharField(max_length=10, choices=ACTION_CHOICES)
